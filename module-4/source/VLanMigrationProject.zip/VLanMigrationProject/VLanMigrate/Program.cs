﻿using System;
using System.IO;
using System.Data;
using System.Collections.Generic;
using GenericParsingCore;      // Dependency from legacy library. Builds to .NET Core without issue.
using CommandLine;             // NuGet package 'CommandLineParser'.  See https://github.com/commandlineparser/commandline
using System.Linq;

namespace VLanMigrate
{

    /********   EXAMPLE INPUT FILE FORMAT - TEXT FILE WITH INDICATED HEADER ********

    NUMBER FAMILY V4V6 ADDRESS SUBNET PRIMARY 
    75 family inet address 10.137.7.253/24
    76 family inet address 10.140.7.253/24
    86 family inet address 10.140.15.253/21
    88 family inet address 10.138.15.253/21
    88 family inet6 address fc00:10:138:8::253/64
    88 family inet6 address fc00:10:138:9::253/64
    88 family inet6 address fc00:10:138:10::253/64 Preferred

    **************************************************************************/

    class Options
    {
        [Option('f', "InputTextFileName", Required = true, Default = null,
          HelpText = "Source file from Juniper router.  See SampleVLANs.txt for example format.")]
        public string InputFile { get; set; }

        [Option('o', "RouterScript1", Required = true, Default = null,
          HelpText = "Target HSRP router1 file. Produce a Cisco script file.")]
        public string RouterScript1 { get; set; }

        [Option('p', "RouterScript2", Required = true, Default = null,
          HelpText = "Target HSRP router2 file. Produce a Cisco script file.")]
        public string RouterScript2 { get; set; }

        [Option('e', "ExceptionLogFilePath", Required = false, Default = null,
          HelpText = "Optional. Produce a EXCEPTION log file.")]
        public string ExceptionLogFile { get; set; }

        [Option('r', "ProduceMinimalIpv6Routes", Required = false, Default = false,
          HelpText = "Optional. Limit the number of dual-stack IPv6 routes per VLAN to the corresponding count within Juniper source file.")]
        public bool ProduceMinimalIpv6Routes { get; set; }

    }


    class MyProgram
    {
        private string _InputFilePath;                   // Path to input file.
        private string _OutputFilePath1;                 // Path to first HSRP router script file.
        private string _OutputFilePath2;                 // Path to second HSRP router script file.
        private bool _ProduceMinimalIpv6Routes;          // Optional input flag that limits the output of dual-stack IPv6 routers per VLAN to the count specified within the input file per VLAN.

        protected DataSet _Records;                      // Input file parsed to a DataSet
        private List<IP4VLan> _ListVLans;                // _Records parsed to a VLans list.

        private string _queryTimeTag;                    // Establish a time-stamp.
        private string _ExceptionLogFile;                // File to receive data-transformation exception data.
        public ExceptionLog _ExceptionLog;               // Helper class.

        static void Main(string[] args)
        {
            MyProgram myApp = new MyProgram();
            myApp._ExceptionLog = new ExceptionLog();

            try
            {
                Parser.Default.ParseArguments<Options>(args)
                   .WithParsed<Options>(o =>
                   {
                       myApp._ProduceMinimalIpv6Routes = o.ProduceMinimalIpv6Routes;

                       if (!string.IsNullOrEmpty(o.InputFile))
                       {
                           myApp._InputFilePath = Path.GetFullPath(o.InputFile);
                       }

                       if (!string.IsNullOrEmpty(o.RouterScript1))
                       {
                           myApp._OutputFilePath1 = Path.GetFullPath(o.RouterScript1);
                       }

                       if (!string.IsNullOrEmpty(o.RouterScript2))
                       {
                           myApp._OutputFilePath2 = Path.GetFullPath(o.RouterScript2);
                       }

                       if (!string.IsNullOrEmpty(o.ExceptionLogFile))
                       {
                           myApp._ExceptionLogFile = Path.GetFullPath(o.ExceptionLogFile);
                       }
                   })
                   .WithNotParsed<Options>((errs) => HandleParseErrors(errs));

                myApp._queryTimeTag = DateTime.Now.ToString("s");

                if (ParseInputFile(ref myApp) == false)
                    throw (new Exception("Further processing halted."));

                if (ParseRecordsSet(ref myApp) == false)
                    throw (new Exception("Further processing halted."));

                if (WriteOutputFiles(ref myApp) == false)
                    throw (new Exception("Further processing halted."));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                myApp._ExceptionLog.LogException("ERROR", ex.ToString(), "EXCEPTION");
            }
            finally
            {
                if (!string.IsNullOrEmpty(myApp._ExceptionLogFile))
                    myApp._ExceptionLog.WriteExceptionLogToFile(myApp._ExceptionLogFile, "VLanMigrate", myApp._queryTimeTag);
                if (myApp._Records != null)
                    myApp._Records.Clear();
                if (myApp._ListVLans != null)
                    myApp._ListVLans.Clear();
            }

            return;
        }

        private static void HandleParseErrors(IEnumerable<Error> errs)
        {
            throw (new Exception(string.Format("Error parsing command line options.")));
        }

        static readonly string[] columns = { "NUMBER", "FAMILY", "V4V6", "ADDRESS", "SUBNET", "PRIMARY" };
        static readonly string requiredHeader = @"NUMBER FAMILY V4V6 ADDRESS SUBNET PRIMARY";

        static private bool ParseInputFile(ref MyProgram myApp)
        {
            Console.WriteLine("\nParsing input file {0}\n", myApp._InputFilePath);

            try
            {
                using (GenericParserAdapter parser = new GenericParserAdapter())
                {
                    parser.SetDataSource(myApp._InputFilePath);
                    parser.ColumnDelimiter = ' ';
                    parser.FirstRowHasHeader = true;
                    myApp._Records = parser.GetDataSet();
                }

                if ((!myApp._Records.Tables["Table1"].Columns.Contains("NUMBER")) ||
                    (!myApp._Records.Tables["Table1"].Columns.Contains("FAMILY")) ||
                    (!myApp._Records.Tables["Table1"].Columns.Contains("V4V6")) ||
                    (!myApp._Records.Tables["Table1"].Columns.Contains("ADDRESS")) ||
                    (!myApp._Records.Tables["Table1"].Columns.Contains("SUBNET")) ||
                    (!myApp._Records.Tables["Table1"].Columns.Contains("PRIMARY")))
                {
                    throw (new Exception(string.Format("Input file missing required column header: {0} ", MyProgram.requiredHeader)));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to parse input file: \n" + ex.ToString());
                return false;
            }
            return true;
        }


        static private bool ParseRecordsSet(ref MyProgram myApp)
        {
            Console.WriteLine("\nParsing VLAN records...\n");

            if (myApp._ListVLans != null)
                myApp._ListVLans.Clear();
            else
                myApp._ListVLans = new List<IP4VLan>();

            try
            {
                foreach (DataRow row in myApp._Records.Tables["Table1"].Rows)
                {
                    if (myApp._ListVLans.FindIndex(v => v.Equals(Globals.GetField(row, "NUMBER"))) >= 0)   // VLan already processed?
                        continue;

                    IP4VLan vlan = null;

                    if (Globals.IsSame(Globals.GetField(row, "V4V6"), "inet"))   // focus only upon IPV4 subnets
                    {
                        IEnumerable<DataRow> query = from record in myApp._Records.Tables["Table1"].AsEnumerable()
                                                     where (record.Field<System.String>("NUMBER").Equals(row.Field<System.String>("NUMBER")))
                                                     select record;

                        // The Above query fails to build with .NET Core 2.2 and earlier because the DataTable AsEnumerable API
                        // is missing from the System.Data namespace. 
                        //
                        // I found a System.Data.DataSetExtensions library via NuGet that did resolve this incompatibility.  - Phil

                        if (query.Count<DataRow>() > 1)   // found more than one row with same vlan number - possible supernet
                        {
                            vlan = new IP4VLan(query, myApp._ProduceMinimalIpv6Routes);
                            myApp._ListVLans.Add(vlan);
                        }
                        else                              // current row is the only row with same vlan number
                        {
                            vlan = new IP4VLan(row, myApp._ProduceMinimalIpv6Routes);
                            myApp._ListVLans.Add(vlan);
                        }
                    }

                    if (vlan != null)
                        Console.WriteLine(string.Format("{0} : {1}", myApp._ListVLans.Count(), vlan.ToString()));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error parsing VLAN records: \n" + ex.ToString());
                return false;
            }
            return true;
        }

        static private bool WriteOutputFiles(ref MyProgram myApp)
        {
            Console.WriteLine("\nWriting output files...\n    {0}\n    {1}", myApp._OutputFilePath1, myApp._OutputFilePath2);
            try
            {
                using (StreamWriter writer1 = new StreamWriter(myApp._OutputFilePath1))
                using (StreamWriter writer2 = new StreamWriter(myApp._OutputFilePath2))
                {
                    foreach (IP4VLan vlan in myApp._ListVLans)
                    {
                        vlan.Write(writer1, writer2);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to create ouput files: \n" + ex.ToString());
                return false;
            }
            return true;
        }

    }

}
