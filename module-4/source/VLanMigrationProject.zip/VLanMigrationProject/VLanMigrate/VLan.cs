﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Data;
using System.IO;

namespace VLanMigrate
{

    /********   EXAMPLE INPUT FILE FORMAT - TEXT FILE WITH INDICATED HEADER ********

    NUMBER FAMILY V4V6 ADDRESS SUBNET PRIMARY 
    75 family inet address 10.137.7.253/24
    76 family inet address 10.140.7.253/24
    86 family inet address 10.140.15.253/21
    88 family inet address 10.138.15.253/21
    88 family inet6 address fc00:10:138:8::253/64
    88 family inet6 address fc00:10:138:9::253/64
    88 family inet6 address fc00:10:138:10::253/64 Preferred

    **************************************************************************/


    class IP4VLan : IDisposable, IEquatable<IP4VLan>
    {
        // GIVEN THESE...
        string _ID;                         // vlan number as string
        int _Number;                        // vlan number as int
        List<string> _Subnets;              // All subnets of form 10.137.7.253/24  (i.e. primary gateway or vip and cidr).
                                            // Is a SuperNet if multiple segments with same ID. Primary subnet is first entry.
        // GENERATE THESE...
        List<string> _HSRP1;                // IPs of router pair participant #1  (conventionally the .252 address within subnet)
        List<string> _HSRP2;                // IP of router pair participant #2  (conventionally the .251 address within subnet)
        List<string> _VIPS;                 // gateways (conventionally the .253 address within subnet)
        List<string> _IPV6Routes;           // list of IPv6 routes if dual-stack configuration enabled
        int _IPV6RoutesLimit;               // limit the total number of calculated IPV6 routes to this value.
        bool _ProduceMinimalIpv6Routes;     // Override the above _IPV6RoutesLimit and produce full route-list per CIDR size

        public bool IsSuperNet()
        {
            if (_Subnets == null)
                return false;
            return (_Subnets.Count > 1);
        }

        public string GetPrimarySubnet()
        {
            if ((_Subnets == null) || (_Subnets.Count == 0))
                return string.Empty;
            return (_Subnets[0]);
        }

        public string GetSecondarySubnets()
        {
            if ((_Subnets == null) || (_Subnets.Count <= 1))
                return string.Empty;

            StringBuilder stringBuilder = new StringBuilder();

            string primary = GetPrimarySubnet();

            foreach(string subnet in _Subnets)
            {
                string secondary = subnet;
                if (Globals.IsDiff(secondary, primary))
                    stringBuilder.Append(secondary + " ");
            }
            return(stringBuilder.ToString());
        }

        private string GetIpFromSubnet(string subnet)     //  input of form 10.137.7.253/24
        {
            Debug.Assert(!string.IsNullOrEmpty(subnet));
            string[] parts = subnet.Split(new char[] { '/' });    
            Debug.Assert(parts.Length == 2);
            return(parts[0]);
        }

        private string GetCidrFromSubnet(string subnet)   //  input of form 10.137.7.253/24
        {
            Debug.Assert(!string.IsNullOrEmpty(subnet));
            string[] parts = subnet.Split(new char[] { '/' });     
            Debug.Assert(parts.Length == 2);
            return (parts[1]);
        }

        private int GetCidrSizeFromSubnet(string subnet)   //  input of form 10.137.7.253/24
        {
            Debug.Assert(!string.IsNullOrEmpty(subnet));
            string cidr = GetCidrFromSubnet(subnet);
            Debug.Assert(!string.IsNullOrEmpty(cidr));
            int value = 0;
            if (int.TryParse(cidr, out value) == false)
                Debug.WriteLine(string.Format("GetCidrSizeFromSubnet : Error parsing string to integer. {0}", subnet));
            return value;
        }

        enum Octets { FIRST = 0, SECOND = 1, THIRD = 2, FOURTH = 3 };

        private int GetOctetFromIp(string ip, Octets octet)      // input in form 10.137.7.253
        {
            Debug.Assert(!string.IsNullOrEmpty(ip));
            string[] octets = ip.Split(new char[] { '.' });
            int value = 0;
            if (int.TryParse(octets[(int)octet], out value) == false)
                Debug.WriteLine(string.Format("GetOctetFromIp : Error parsing string to integer. {0}", ip));
            return value;
        }

        public void Dispose()
        {
            Debug.WriteLine("VLan : Dispose");
            if (_Subnets != null) _Subnets.Clear();
            if (_HSRP1 != null) _HSRP1.Clear();
            if (_HSRP2 != null) _HSRP2.Clear();
            if (_VIPS != null) _VIPS.Clear();
            if (_IPV6Routes != null) _IPV6Routes.Clear();
        }

        public IP4VLan()
        {
            _ID = string.Empty;
            _Number = 0;
            _Subnets = new List<string>();

            _HSRP1 = new List<string>();
            _HSRP2 = new List<string>();
            _VIPS = new List<string>();
            _IPV6Routes = new List<string>();
            _IPV6RoutesLimit = 0;               
            _ProduceMinimalIpv6Routes = false;   
        }

        public IP4VLan(DataRow row, bool produceMinimalIpv6Routes=false)    // single VLan specified by source DataRow
        {
            Debug.Assert(row != null);

            // set instance parameters
            _ID = Globals.GetField(row, "NUMBER");
            if (int.TryParse(_ID, out _Number) == false)
                throw new Exception(string.Format("IP4VLan : Invalid VLAN number or ID : {0} : {1}", _ID, Globals.GetField(row, "SUBNET")));

            string primarySubnet = Globals.GetField(row, "SUBNET");

            _Subnets = new List<string>();
            _HSRP1 = new List<string>();
            _HSRP2 = new List<string>();
            _VIPS = new List<string>();
            _IPV6Routes = new List<string>();
            _IPV6RoutesLimit = 0;                  // currently, any standalone VLAN requires no inet6 dual-stack addresses. Preference.
            _ProduceMinimalIpv6Routes = produceMinimalIpv6Routes;

            _Subnets.Add(primarySubnet);
            _VIPS.Add(GetIpFromSubnet(primarySubnet));

            ParseHsrp();
            ParseDualStackRoutes();
            return;
        }

        public IP4VLan(IEnumerable<DataRow> rows, bool produceMinimalIpv6Routes = false)
        {
            Debug.Assert(rows != null);

            _Subnets = new List<string>();
            _HSRP1 = new List<string>();
            _HSRP2 = new List<string>();
            _VIPS = new List<string>();
            _IPV6Routes = new List<string>();
            _ProduceMinimalIpv6Routes = produceMinimalIpv6Routes;

            // Are there IPV6 dual-stack routes specified?  How Many?
            IEnumerable<DataRow> v6query = from record in rows
                                           where (record["V4V6"].Equals("inet6"))
                                           select record;
            _IPV6RoutesLimit = v6query.Count<DataRow>();

            // Is this an IPV4 SuperNet - i.e. multiple IPV4 subnets with same VLAN number?
            IEnumerable<DataRow> v4query = from record in rows
                                         where (record["V4V6"].Equals("inet"))
                                         select record;

            // No IPv4 subnets found in rows collections?
            if (v4query.Count<DataRow>() == 0)
                throw new Exception(string.Format("IP4VLan : No IPv4 subnets found with this provided VLAN specification : {0} : {1}", 
                                    Globals.GetField(rows.FirstOrDefault(), "NUMBER"), Globals.GetField(rows.FirstOrDefault(), "SUBNET")));

            // Use the first result entry as the primary subnet
            DataRow primary = v4query.FirstOrDefault();
            _ID = Globals.GetField(primary, "NUMBER");
            if (int.TryParse(_ID, out _Number) == false)
                throw new Exception(string.Format("IP4VLan : Invalid VLAN number or ID : {0} : {1}", _ID, Globals.GetField(primary, "SUBNET")));

            // Capture each result entry within subnets and vips list
            foreach (DataRow row in v4query)
            {
                string subnet = Globals.GetField(row, "SUBNET");
                if (_Subnets.Contains(subnet))                      // subnet already processed?  original input data has duplicates.
                    continue;
                _Subnets.Add(subnet);
                _VIPS.Add(GetIpFromSubnet(subnet));
            }

            ParseHsrp();
            ParseDualStackRoutes();
            return;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            IP4VLan objAs = obj as IP4VLan;
            if (objAs == null) return false;
            else return Equals(objAs);
        }

        public bool Equals(string number)
        {
            return (Globals.IsSame(this._ID, number));
        }

        public bool Equals(int number)
        {
            return (number == this._Number);
        }

        public bool Equals(IP4VLan other)
        {
            if (other == null) return false;
            return (this._Number == other._Number);
        }

        public override int GetHashCode()
        {
            return this._Number;
        }

        public override string ToString()
        {
            return (string.Format("VLAN={0} : {1} {2}", this._ID, this.GetPrimarySubnet(), this.GetSecondarySubnets()));
        }


        private bool ParseHsrp()
        {
            Debug.Assert(this._Subnets.Count > 0);
            Debug.Assert(this._HSRP1 != null);
            Debug.Assert(this._HSRP2 != null);

            foreach (string subnet in _Subnets)
            {
                string vip = GetIpFromSubnet(subnet);
                string cidr = GetCidrFromSubnet(subnet);
                int gw = GetOctetFromIp(vip, Octets.FOURTH);
                string[] octets = vip.Split(new char[] { '.' });
                string baseaddress = octets[0] + "." + octets[1] + "." + octets[2] + ".";

                _HSRP1.Add(string.Format(baseaddress + (gw - 2).ToString() + "/" + cidr));
                _HSRP2.Add(string.Format(baseaddress + (gw - 1).ToString() + "/" + cidr));
            }
            return true;
        }


        const string ROUTE = "ipv6 address fc00:10:{0}:{1}::{2}/64";

        private bool ParseDualStackRoutes()
        {
            Debug.Assert(this._Subnets.Count > 0);

            if ((this._ProduceMinimalIpv6Routes) && (this._IPV6RoutesLimit <= 0))        // Preference... some vlans require no IPV6 routes.
                return true;

            string vip = GetIpFromSubnet(_Subnets[0]);
            int thirdOctet = GetOctetFromIp(vip, Octets.THIRD);
            string[] octets = vip.Split(new char[] { '.' });
            int cidrSize = GetCidrSizeFromSubnet(_Subnets[0]);

            int numroutes = 0;

            switch (cidrSize)
            {
                case 24: numroutes = 1; break;
                case 23: numroutes = 2; break;
                case 22: numroutes = 4; break;
                case 21: numroutes = 8; break;
                case 20: numroutes = 16; break;
                case 19: numroutes = 32; break;
                case 18: numroutes = 64; break;
                case 17: numroutes = 128; break;
                case 16: numroutes = 256; break;
                default:
                {
                    if (cidrSize < 16)
                    {
                        numroutes = 256;
                        Debug.WriteLine("\nWARNING : number of routes in excess of 256 ignored.  CIDR size = {0} : Routes={1}\n", cidrSize, numroutes);
                    }
                    break;
                }
            }

            if ((this._ProduceMinimalIpv6Routes) && (numroutes > this._IPV6RoutesLimit))          // Preference... some vlans require a limited number IPV6 routes.
                numroutes = this._IPV6RoutesLimit;

            for (int lcv = thirdOctet; lcv > (thirdOctet - numroutes) ; lcv--)
            {
                string route = string.Format(ROUTE, octets[1], lcv, octets[3]);
                _IPV6Routes.Add(route);
            }
            return true;
        }

        const string VLAN_COMMENT = "\n## {0} \n";

        const string VLAN_CONFIG =
                    "interface Vlan{0} \n" +
                    "shutdown \n" +
                    "no ip redirects " +
                    "{1} " +                                    // HSRP's : ip address {ip0} \n + ip address {ip1} secondary \n + ip address {ip2} secondary \n
                    "\nip ospf passive-interface \n" +
                    "ip router ospf 1 area 0.0.0.51 \n" +
                    "ospfv3 passive-interface \n" +
                    "ipv6 router ospfv3 1 area 0.0.0.51" +
                    "{2}" +                                     // IPv6 routes
                    "\nhsrp version 2 \n" +
                    "hsrp 90" +
                    "{3} " +                                    // VIPS : ip {vip0} \n + ip {vip1} secondary \n + ip {vip2} secondary \n
                    "\nip dhcp relay address 10.142.7.15 \n" +
                    "ip dhcp relay address 10.142.7.16 \n" +
                    "ip dhcp relay address 10.132.7.6 \n" +
                    "ip dhcp relay address 10.142.7.86 \n" +
                    "ipv6 dhcp relay address fc00:10:142:7::15 \n" +
                    "ipv6 dhcp relay address fc00:10:142:7::16 \n" +
                    "ipv6 dhcp relay address fc00:10:142:7::86";

        public bool Write(StreamWriter writer1, StreamWriter writer2)
        {
            Debug.Assert(this._Subnets.Count > 0);
            Debug.Assert(writer1 != null);
            Debug.Assert(writer2 != null);

            StringBuilder hsrp1 = new StringBuilder();
            StringBuilder hsrp2 = new StringBuilder();
            StringBuilder v6routes1 = new StringBuilder();
            StringBuilder v6routes2 = new StringBuilder();
            StringBuilder vips = new StringBuilder();

            // Format HSRP1 Addresses
            for (int lcv=0; lcv < _HSRP1.Count; lcv++)
            {
                hsrp1.Append(string.Format("\nip address {0} ", _HSRP1[lcv]));
                if (lcv != 0)
                    hsrp1.Append("secondary");
            }

            // Format HSRP2 Addresses
            for (int lcv = 0; lcv < _HSRP2.Count; lcv++)
            {
                hsrp2.Append(string.Format("\nip address {0} ", _HSRP2[lcv]));
                if (lcv != 0)
                     hsrp2.Append("secondary");
            }

            // Format IPV6 Routes
            if (_IPV6Routes.Count > 0)
            {
                if (_IPV6Routes.Count == 1)
                {
                    v6routes1.Append("\n" + _IPV6Routes[0]);
                    // v6routes2.Append("\n" + _IPV6Routes[0]);   // With /24 subnets, only 1 router gets the IPv6 route configuration
                }
                else
                {
                    int routesplit = _IPV6Routes.Count / 2;
                    for (int lcv = 0; lcv < routesplit; lcv++)
                    {
                        v6routes2.Append("\n" + _IPV6Routes[lcv]);
                    }
                    for (int lcv = routesplit; lcv < _IPV6Routes.Count; lcv++)
                    {
                        v6routes1.Append("\n" + _IPV6Routes[lcv]);
                    }
                }
            }

            // Format VIPS
            for (int lcv = 0; lcv < _VIPS.Count; lcv++)
            {
                vips.Append(string.Format("\n  ip {0} ", _VIPS[lcv]));
                if (lcv != 0)
                    vips.Append("secondary");
            }

            // Write first HSRP Profile...
            writer1.WriteLine(string.Format(VLAN_COMMENT, this.ToString()));
            writer1.WriteLine(string.Format(VLAN_CONFIG, this._ID, hsrp1.ToString(), v6routes1.ToString(), vips.ToString()));

            // Write second HSRP Profile...
            writer2.WriteLine(string.Format(VLAN_COMMENT, this.ToString()));
            writer2.WriteLine(string.Format(VLAN_CONFIG, this._ID, hsrp2.ToString(), v6routes2.ToString(), vips.ToString()));
            return true;
        }

    }
}
